async function buatPesanan() {
    const produk = document.getElementById("produk").value;

    // Contoh request ke API OrderKuota
    const apiKey = "671597417363549002219753OKCT1E9C0C92AE2B811D9B21E8862D3F34C5";
    const kodeProduk = "OK2219753";

    const res = await fetch(`https://api.orderkuota.com/v1/order?apikey=${apiKey}&product=${kodeProduk}&note=${produk}`);
    const data = await res.json();

    if (data.status === "success") {
        document.getElementById("qris").style.display = "block";
    } else {
        alert("Gagal membuat pesanan: " + data.message);
    }
}